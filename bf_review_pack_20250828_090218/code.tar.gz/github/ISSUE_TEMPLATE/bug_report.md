---
name: Bug report
about: Reportar um problema
labels: bug
---

**Descrição do bug**
O que aconteceu?

**Como reproduzir**
Passos:
1. …
2. …

**Comportamento esperado**
…

**Logs/prints**
(cole logs relevantes, sem segredos)

**Ambiente**
- SO/VM:
- Python:
- Branch/commit:
