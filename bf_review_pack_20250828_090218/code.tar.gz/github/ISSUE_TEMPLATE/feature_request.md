---
name: Feature request
about: Sugerir melhoria/funcionalidade
labels: enhancement
---

**Problema/objetivo**
O que deseja resolver?

**Proposta**
Como a feature funcionaria?

**Impacto e riscos**
…

**Checklist**
- [ ] Desenho/escopo definido
- [ ] Métrica de sucesso
