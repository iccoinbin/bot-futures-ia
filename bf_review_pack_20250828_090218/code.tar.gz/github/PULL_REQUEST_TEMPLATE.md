## Resumo
Descreva o que este PR faz e por quê.

## Mudanças
- [ ] …

## Checklist
- [ ] CI passou (lint/tests)
- [ ] Sem segredos/credenciais nos commits
- [ ] Atualiza docs/README se necessário
- [ ] Testado localmente

## Riscos e plano de rollback
- Risco: …
- Rollback: reverter commit X ou `git revert <sha>`
