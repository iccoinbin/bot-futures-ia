# === RISK KERNEL (auto-injetado) ===
try:
    from common.risk_kernel import RiskKernel
    rk = RiskKernel.from_env()
    print("[RISK_INIT] RiskKernel carregado")
except Exception as e:
    print(f"[RISK_INIT_WARNING] {e}")
    rk = None
# === /RISK KERNEL ===
import os, hmac, hashlib, time, json, yaml, requests, argparse
from urllib.parse import urlencode
from datetime import datetime, timezone
import pandas as pd
from pathlib import Path
from src.features.ta_v31 import build_features

def base_url(testnet: bool):
    return "https://testnet.binancefuture.com" if testnet else "https://fapi.binance.com"
def ts_ms(): return int(time.time()*1000)
def sign(params: dict, secret: str):
    qs = urlencode(params, True)
    sig = hmac.new(secret.encode(), qs.encode(), hashlib.sha256).hexdigest()
    return qs + "&signature=" + sig
def headers(key: str): return {"X-MBX-APIKEY": key}
def api_get(url, params, key, secret):
    params = {**params, "timestamp": ts_ms(), "recvWindow": 60000}
    full = url + "?" + sign(params, secret)
    return requests.get(full, headers=headers(key), timeout=15)
def api_post(url, params, key, secret):
    params = {**params, "timestamp": ts_ms(), "recvWindow": 60000}
    return requests.post(url, headers=headers(key), data=sign(params, secret), timeout=15)
def api_delete(url, params, key, secret):
    params = {**params, "timestamp": ts_ms(), "recvWindow": 60000}
    return requests.delete(url + "?" + sign(params, secret), headers=headers(key), timeout=15)

def fetch_klines(symbol: str, interval: str, limit: int, testnet: bool) -> pd.DataFrame:
    url = f"{base_url(testnet)}/fapi/v1/klines"
    r = requests.get(url, params={"symbol": symbol, "interval": interval, "limit": limit}, timeout=12)
    r.raise_for_status()
    cols=["open_time","open","high","low","close","volume","close_time","qav","num_trades","taker_base","taker_quote","ignore"]
    df = pd.DataFrame(r.json(), columns=cols)
    df["open_time"]  = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df["close_time"] = pd.to_datetime(df["close_time"], unit="ms", utc=True)
    for c in ["open","high","low","close","volume","qav","taker_base","taker_quote"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.sort_values("close_time").reset_index(drop=True)

def decide_and_size(feats: pd.DataFrame, cfg: dict):
    ex   = cfg["execution"]; risk = cfg["risk"]; flt = cfg["filters"]
    last = feats.iloc[-1]
    price = float(last["close"]); atr = float(last["atr"]); adx = float(last["adx"])
    emaf = float(last["ema_fast"]); emas=float(last["ema_slow"])
    adx_min = float(flt["adx_trend_min"]); trend = adx >= adx_min
    side = 0
    if trend and emaf > emas: side = +1
    elif trend and emaf < emas: side = -1
    sl_mult=float(ex["sl_atr_mult"]); tp_mult=float(ex["tp_atr_mult"])
    cap=float(risk["capital_usdt"]); rpct=float(risk["risk_per_trade_pct"])/100.0
    r_val=max(1e-9, sl_mult*atr); qty=(cap*rpct)/r_val
    if side>0: sl=price - sl_mult*atr; tp=price + tp_mult*atr
    elif side<0: sl=price + sl_mult*atr; tp=price - tp_mult*atr
    else: sl=tp=None
    return dict(side=side, qty=qty, price=price, sl=sl, tp=tp)

def ensure_isolated_and_leverage(symbol, lev, key, secret, testnet):
    base = base_url(testnet)
    try: api_post(f"{base}/fapi/v1/marginType", {"symbol":symbol, "marginType":"ISOLATED"}, key, secret)
    except Exception as e: print("[executor] marginType:", repr(e))
    try: api_post(f"{base}/fapi/v1/leverage", {"symbol":symbol, "leverage":lev}, key, secret)
    except Exception as e: print("[executor] leverage:", repr(e))

def get_position_amt(symbol, key, secret, testnet):
    base = base_url(testnet)
    r = api_get(f"{base}/fapi/v2/positionRisk", {"symbol":symbol}, key, secret)
    if r.status_code!=200: return 0.0
    for pos in r.json():
        if pos["symbol"]==symbol:
            try: return float(pos["positionAmt"])
            except: return 0.0
    return 0.0

def cancel_all_open(symbol, key, secret, testnet):
    base = base_url(testnet)
    api_delete(f"{base}/fapi/v1/allOpenOrders", {"symbol":symbol}, key, secret)

def place_entry(symbol, side, qty, price, mode, key, secret, testnet):
    # === Risk/OCO Adapter Início ===
    if rk and not rk.check_gate(symbol, side, qty):
        print(f"[RISK_GATE] Bloqueado por risco: {symbol} {side} {qty}")
        return None
    # === Risk/OCO Adapter Fim ===
    base = base_url(testnet)
    side_str = "BUY" if side>0 else "SELL"
    client_id = f"botv33-{symbol}-{int(time.time()*1000)}"
    if mode=="maker_first":
        params = {"symbol":symbol,"side":side_str,"type":"LIMIT","timeInForce":"GTX",
                  "quantity":round(qty,6),"price":f"{price:.2f}","newClientOrderId":client_id}
    else:
        params = {"symbol":symbol,"side":side_str,"type":"MARKET",
                  "quantity":round(qty,6),"newClientOrderId":client_id}
    return api_post(f"{base}/fapi/v1/order", params, key, secret)

def place_oco_exits(symbol, side, qty, tp, sl, key, secret, testnet):
    base = base_url(testnet)
    close_side = "SELL" if side>0 else "BUY"
    qty = round(qty, 6)
    tp_r = api_post(f"{base}/fapi/v1/order", {
        "symbol": symbol, "side": close_side, "type": "TAKE_PROFIT_MARKET",
# === RISK FILL (auto-injetado) ===
    try:
        _pnl = realized_pnl_usdt
    except NameError:
        try:
            _pnl = realized_pnl
        except NameError:
            try:
                _pnl = pnl_usdt
            except NameError:
                try:
                    _pnl = pnl
                except NameError:
                    _pnl = 0.0
    try:
        _risk_report_fill(_pnl)
    except Exception as _e:
        print(f"[RISK] Falha ao chamar _risk_report_fill: {_e}")
    # === /RISK FILL ===
        "stopPrice": f"{tp:.2f}", "closePosition": "true", "reduceOnly": "true",
        "newClientOrderId": f"tp-{int(time.time()*1000)}"
    }, key, secret)
    sl_r = api_post(f"{base}/fapi/v1/order", {
        "symbol": symbol, "side": close_side, "type": "STOP_MARKET",
        "stopPrice": f"{sl:.2f}", "closePosition": "true", "reduceOnly": "true",
        "newClientOrderId": f"sl-{int(time.time()*1000)}"
    }, key, secret)
    return tp_r, sl_r

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", type=str, default=None)
    ap.add_argument("--timeframe", type=str, default=None)
    ap.add_argument("--dry-run", type=str, default=None, help="true/false para sobrescrever runtime.dry_run")
    args = ap.parse_args()

    cfg = yaml.safe_load(open("config/settings_v31.yml"))
    rt  = cfg.setdefault("runtime", {})
    sym = (args.symbol or rt.get("symbol","BTCUSDT")).upper()
    tf  = (args.timeframe or rt.get("timeframe","5m")).lower()
    poll = int(rt.get("poll_interval_sec",10))
    hist_min = int(rt.get("history_minutes",600))
    dry_run = rt.get("dry_run", True)
    if args.dry_run is not None:
        dry_run = str(args.dry_run).strip().lower() in ("1","true","yes","y")

    testnet = bool(cfg.get("binance",{}).get("testnet",True))
    API_KEY = os.getenv("BINANCE_API_KEY", cfg.get("binance",{}).get("api_key",""))
    API_SECRET = os.getenv("BINANCE_API_SECRET", cfg.get("binance",{}).get("api_secret",""))
    if not API_KEY or not API_SECRET:
        print("[executor] ERRO: faltam API keys (BINANCE_API_KEY/SECRET ou YAML)."); raise SystemExit(1)

    try: ensure_isolated_and_leverage(sym, 2, API_KEY, API_SECRET, testnet)
    except Exception as e: print("[executor] prep isolated/leverage:", repr(e))

    logs = Path("logs"); logs.mkdir(parents=True, exist_ok=True)
    intents_csv = logs / f"live_intents_{sym}_{tf}.csv"
    state_file  = logs / f"live_state_{sym}_{tf}.json"
    state = {"pos": 0, "qty": 0.0, "last_bar": None}
    if state_file.exists():
        try: state.update(json.loads(state_file.read_text()))
        except: pass

    KILL_SWITCH_MDD_PCT = 8.0  # corta se MDD passar disso (teste)
print(f"[executor] START sym={sym} tf={tf} testnet={testnet} dry_run={dry_run}")
    mdd_accum = 0.0
while True:
        try:
            limit = max(200, hist_min // (1 if tf.endswith("m") else 5))
            url = f"{base_url(testnet)}/fapi/v1/klines"
            r = requests.get(url, params={"symbol": sym, "interval": tf, "limit": limit}, timeout=12)
            r.raise_for_status()
            cols=["open_time","open","high","low","close","volume","close_time","qav","num_trades","taker_base","taker_quote","ignore"]
            raw = pd.DataFrame(r.json(), columns=cols)
            raw["open_time"]=pd.to_datetime(raw["open_time"],unit="ms",utc=True)
            raw["close_time"]=pd.to_datetime(raw["close_time"],unit="ms",utc=True)
            for c in ["open","high","low","close","volume","qav","taker_base","taker_quote"]:
                raw[c]=pd.to_numeric(raw[c], errors="coerce")
            raw=raw.sort_values("close_time").reset_index(drop=True)

            feats = build_features(raw, cfg["indicators"]["ema_fast"], cfg["indicators"]["ema_slow"],
                                   cfg["indicators"]["atr_period"], cfg["indicators"]["adx_period"],
                                   cfg["indicators"].get("vwap_window",20))

            ex   = cfg["execution"]; dec = decide_and_size(feats, cfg)
            bar_close = raw.iloc[-1]["close_time"].isoformat()
            if bar_close == state.get("last_bar"):
                time.sleep(poll); continue

            onexch_amt = get_position_amt(sym, API_KEY, API_SECRET, testnet)
            exch_pos = 1 if onexch_amt>0 else (-1 if onexch_amt<0 else 0)

            action = "HOLD"
            if dec["side"] != exch_pos:
                try: cancel_all_open(sym, API_KEY, API_SECRET, testnet)
                except Exception as e: print("[executor] cancel_all_open:", repr(e))

                if dec["side"] == 0:
                    action = "FLATTEN"
                    if not dry_run and exch_pos != 0:
                        side_str = "SELL" if exch_pos>0 else "BUY"
                        r = api_post(f"{base_url(testnet)}/fapi/v1/order",
                                     {"symbol":sym, "side":side_str, "type":"MARKET", "reduceOnly":"true",
                                      "quantity":abs(onexch_amt)}, API_KEY, API_SECRET)
                        print("[executor] flatten resp:", r.status_code, r.text)
                else:
                    action = "OPEN_LONG" if dec["side"]>0 else "OPEN_SHORT"
                    if not dry_run:
                        r_entry = place_entry(sym, dec["side"], dec["qty"], dec["price"],
                                              ex.get("mode","maker_first"),
                                              API_KEY, API_SECRET, testnet)
                        print("[executor] entry resp:", r_entry.status_code, r_entry.text)
                        time.sleep(0.3)
                        r_tp, r_sl = place_oco_exits(sym, dec["side"], dec["qty"], dec["tp"], dec["sl"],
                                                     API_KEY, API_SECRET, testnet)
                        print("[executor] tp resp:", r_tp.status_code, r_tp.text)
                        print("[executor] sl resp:", r_sl.status_code, r_sl.text)

                row = {
                    "time_utc": datetime.now(timezone.utc).isoformat(),
                    "bar_close": bar_close, "symbol": sym, "tf": tf,
                    "action": action, "qty": round(dec["qty"],6), "price": round(dec["price"],2),
                    "tp": round(dec["tp"],2) if dec["tp"] else None,
                    "sl": round(dec["sl"],2) if dec["sl"] else None,
                    "dry_run": dry_run
                }
                mdd_accum = max(mdd_accum, 0.0)  # placeholder simples; plugue PnL real aqui
pd.DataFrame([row]).to_csv(intents_csv, index=False, mode="a", header=not intents_csv.exists())
                print(f"[executor] {row['action']} | qty {row['qty']} | px {row['price']} | tp/sl {row['tp']}/{row['sl']} | dry_run={dry_run}")

            state["last_bar"] = bar_close
            state_file.write_text(json.dumps(state))
        except Exception as e:
            print("[executor][erro]", repr(e))
        time.sleep(poll)

# === EQUITY PROVIDER (provisório via .env) ===
import os

def get_equity_usdt(_client=None) -> float:
    """
    Retorna o equity em USDT.
    Versão provisória: lê EQUITY_OVERRIDE_USDT do .env.
    Trocaremos por leitura real da conta no próximo passo.
    """
    try:
        return float(os.getenv("EQUITY_OVERRIDE_USDT", "5000"))
    except Exception:
        return 5000.0
# === /EQUITY PROVIDER ===

# === RISK FILL REPORT helper (auto-injetado) ===
def _risk_report_fill(pnl_value):
    try:
        if rk is not None:
            _p = float(pnl_value)
            rk.on_fill(realized_pnl_usdt=_p, is_closed_trade=True, is_win=(_p>0))
            print(f"[RISK] on_fill reportado: pnl={_p}")
    except Exception as _e:
        print(f"[RISK] Falha ao reportar fill: {_e}")
# === /RISK FILL REPORT ===
